from ..BaseModule import BaseModule

class Loss(BaseModule):

	def __init__(self):
		super(Loss, self).__init__()